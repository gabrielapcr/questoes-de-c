#include <stdio.h>
int main (void){
    // receber os parametros da matriz e recber os votos 
    int princess, voters ,i ,j,vote[100][100],cont[100],somac ;
    scanf("%d %d",&princess,&voters);
    for (i = 0 ; i < voters;i ++){
        for(j = 0 ; j< princess;j ++){
            scanf("%d",&vote[i][j]);
    
        }
     printf("\n");  
    }
     for(j = 0 ; j<= princess;j ++){
         somac = 0;
         for (i = 0 ; i <=voters ;i ++){
             
             somac += vote[i][j];
         }
         cont[j]= somac;
     }
    // armazenar os votos de cada princessa 
    
        for(j = 0 ; j< princess;j ++){
            printf("\nPrincesa %d: %d voto(s)",j + 1,cont[j]);

    }


	return 0;


}