#include <stdio.h>
#include <stdlib.h>

int linhas, colunas, tamanho;
int main(){
    scanf("%d %d", &linhas, &colunas);

    int m, n, matriz[linhas][colunas];
    for (m = 0; m < linhas; m++)
    {

        for (n = 0; n < colunas; n++)
        {
            scanf(" %d", &matriz[m][n]);
        }
    }
    scanf(" %d", &tamanho);

    int j, valor;
    for (j = 0; j < tamanho; j++)
    {
        scanf(" %d", &valor);

        int num_presente = 0, i1 = 0, i2 = 0;
        if (valor < matriz[linhas-1][colunas-1])
        {
            for (m = 0; m < linhas; m++)
            {

                if (matriz[m][0] <= valor && valor <= matriz[m][colunas-1])
                {
                    for (n = 0; n < colunas; n++)
                    {
                        if (valor == matriz[m][n])
                        {
                            num_presente = 1;
                            i1 = m;
                            i2 = n;
                            break;
                        }
                    }
                }
                if(num_presente == 1)
                {
                    break;
                }
            }
        }
        if (num_presente == 1)
        {
            printf("YES WITH %d AND %d\n", i1 + 1, i2 + 1);
        }
        else
        {
            printf("NO\n");
        }
    }
}